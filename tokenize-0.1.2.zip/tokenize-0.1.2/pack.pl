name(tokenize).
title('A nascent tokenization library').

version('0.1.2').
download('https://github.com/aBathologist/tokenize/release/*.zip').

author('Shon Feder', 'shon.feder@gmail.com').
packager('Shon Feder', 'shon.feder@gmail.com').
maintainer('Shon Feder', 'shon.feder@gmail.com').
home('https://github.com/aBathologist/tokenize').
